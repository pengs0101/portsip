# portsip-ha-guide-offline
The PortSIP High Availability for offline installation, please read docs/install.md
