# open(/dev/pbxvg/pbxlv) failed: No such file or directory
```

--==  Thank you for participating in the global usage survey  ==--
The server's response is:

you are the 20414th user to install this version
open(/dev/pbxvg/pbxlv) failed: No such file or directory
open(/dev/pbxvg/pbxlv) failed: No such file or directory
Command 'drbdmeta 1 v09 /dev/pbxvg/pbxlv internal create-md 2' terminated with exit code 20


如果出现如上报错，你需要修改pbxdata.res文件中/dev/pbxvg/pbxlv改为/dev/centos/pbxlv，重新执行

cp -f pbxdata.res /etc/drbd.d/
scp  pbxdata.res pbx02:/etc/drbd.d/
scp  pbxdata.res pbx03:/etc/drbd.d/
```


















