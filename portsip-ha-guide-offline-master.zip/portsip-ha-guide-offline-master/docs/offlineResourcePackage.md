# 制作离线安装离线资源包

```
下载离线资源包

wget http://www.portsip.cn/downloads/portsip-pbx-ha-guide-12.3.2.105.tar.gz


tar xf portsip-pbx-ha-guide-12.3.2.105.tar.gz


删除资源包里面的镜像文件
cd portsip-pbx-ha-guide
rm -f pbx.tar.gz.gz

导出新的docker 镜像文件（离线镜像为portsip/pbx:12，根据需求替换）
docker save portsip/pbx:12 -o pbx.tar.gz
tar zcvf pbx.tar.gz.gz ./pbx.tar.gz
rm -f pbx.tar.gz


生成新的离线安装资源包(portsip-pbx-ha-guide-12.3.2.105.tar.gz是新的资源包名字，可以根据需求更改)
cd ..
tar zcvf portsip-pbx-ha-guide-12.3.2.105.tar.gz ./portsip-pbx-ha-guide

```

# 离线资源包脚本用途

**deploy-ansible.sh**
```
离线安装anbile

```
**create_pacemaker_resources.sh**
```
创建pacemaker资源脚本
```


**delete_pacemaker_resources.sh**
```
删除pacemaker 资源脚本
```
**docker.sh**
```
运行容器并停止容器脚本
```
**install-off-line.sh**
```
安装配置yum缓存
```
**init-pacemaker.sh**

```
配置pacemaker集群脚本
```
**vars.yml**
```
ansible 需要的一些参数配置文件，比较vip 镜像版本
```
****

**install.sh**
```
安装需要的组件，pacemaker drbd
```

**install.yml**

```
ansible 剧本文件，上面一些安装脚本，都由ansible自动调用
```